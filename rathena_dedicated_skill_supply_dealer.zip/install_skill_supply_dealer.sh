#!/usr/bin/env bash
set -euo pipefail

ROOT="/opt/rathena"
cd "$ROOT"

stamp="$(date +%Y%m%d-%H%M%S)"
cp -a npc/scripts_custom.conf "npc/scripts_custom.conf.bak.$stamp"

# Remove the previous dynamic injector if it was installed.
sed -i '\#^npc: npc/custom/tool_dealer_skill_supplies.txt$#d' npc/scripts_custom.conf

# Enable the new standalone shop exactly once.
grep -qxF 'npc: npc/custom/skill_supply_dealer.txt' npc/scripts_custom.conf || \
  printf '\nnpc: npc/custom/skill_supply_dealer.txt\n' >> npc/scripts_custom.conf

# Confirm file and import line before restart.
test -f npc/custom/skill_supply_dealer.txt
grep -nF 'npc: npc/custom/skill_supply_dealer.txt' npc/scripts_custom.conf

echo 'Installed. Restart map-server with: ./athena-start restart'
