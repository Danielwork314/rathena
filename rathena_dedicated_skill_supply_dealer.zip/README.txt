Standalone Skill Supply Dealer

Location:
  map: prontera
  coordinate: 160,180
  NPC name: Skill Supply Dealer

This shop does not depend on:
  npc/merchants/shops.txt
  npc/re/merchants/Dealer_Update.txt
  feature.barter

Install from /opt/rathena:
  unzip -o rathena_dedicated_skill_supply_dealer.zip -d /opt/rathena
  cd /opt/rathena
  sudo bash install_skill_supply_dealer.sh
  sudo ./athena-start restart

In game:
  @warp prontera 160 180
